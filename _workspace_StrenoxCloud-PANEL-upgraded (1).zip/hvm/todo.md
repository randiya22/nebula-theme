# HVM Panel Upgrade Plan

## 1. Remove "Create Account"
- [x] Remove register link from login.html
- [x] Replace register CTAs in index.html (landing)
- [x] Remove Register button from base.html header
- [x] Disable /register route (redirect to login) + registration setting
- [x] Neutralize remaining "register"/"create account" copy across templates

## 2. Swap RAM (user-facing)
- [x] Add POST /vps/<id>/swap backend route
- [x] Add swap modal UI + slider/number/presets in vps_detail.html
- [x] Add JS showSwapModal/updateSwap + live display
- [x] Make swap row in RAM card clickable
- [x] Clean config string units (GB RAM / vCPU / GB Disk / Swap)

## 3. UI Animations + cPanel-professional polish
- [x] Create static/css/pro.css (loaded after ultra.css)
- [x] Add auto scroll-reveal + stagger + counter animation JS in base.html
- [x] Enhance auth/login animations
- [x] Professional refinements (cards, gauges, header, sidebar, buttons)

## 4. Verify & Deliver
- [x] Run app, screenshot login/dashboard/vps detail
- [x] Verify swap modal renders (Off/1/2/4/8/16 GB + Apply)
- [x] Verify swap persists to DB + config string
- [x] Package final zip
