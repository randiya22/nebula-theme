Place `urldownloader-v1.1.1.blueprint` in `/var/www/pterodactyl`
(use your custom panel path if you changed it during installation)

Run:
blueprint -i urldownloader-v1.1.1
